# WP Arzo - WordPress Maintenance & Administration Suite

**Version:** 5.1
**Author:** Yasir Shabbir
**Website:** [yasirshabbir.com](https://yasirshabbir.com)
**GitHub:** [github.com/yasirshabbirservices/maintenance-tool](https://github.com/yasirshabbirservices/maintenance-tool)

## Description

WP Arzo is the ultimate WordPress maintenance and administration suite that provides a comprehensive set of tools for managing your WordPress site. This plugin version offers the same powerful features as the standalone tool, but integrated directly into your WordPress admin panel.

## Features

- **Site Information** - View detailed WordPress, PHP, MySQL, and server information
- **User Management** - Create, edit, delete users, and login as any user
- **Database Management** - Browse, optimize, repair, and export database tables
- **File Browser** - View, edit, download, and manage files directly from the admin panel
- **Plugin Manager** - Activate, deactivate, and manage plugins
- **Theme Manager** - Switch themes and manage theme files
- **Debug Tools** - Enable/disable debugging, view debug logs
- **Maintenance Modes** - Enable frontend/backend maintenance modes
- **Extra Options** - Configure PHP limits and other advanced settings
- **Quick Login** - Create temporary admin accounts and login as any user

## Installation

1. Upload the `wp-arzo-plugin` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Click on 'WP Arzo' in the admin menu to open the tool in a new tab

## Usage

Once activated, you'll see a new menu item called "WP Arzo" in your WordPress admin panel with a tools icon. Click on it to open the maintenance tool in a new tab.

The tool opens in a clean, distraction-free interface (no WordPress admin UI elements) so you can focus on maintenance tasks.

## Security

- Only users with `manage_options` capability (administrators) can access the tool
- No external access key required - uses WordPress's built-in authentication
- All actions are protected by WordPress capability checks

## Requirements

- WordPress 5.0 or higher
- PHP 7.2 or higher
- Administrator access

## Changelog

### Version 5.1
- Converted standalone tool into WordPress plugin
- Added WordPress admin menu integration
- Removed external ACCESS_KEY authentication (uses WordPress auth)
- Opens in new tab with clean UI (no WordPress dashboard elements)
- Maintained all original features and functionality

## Support

For support, please contact: [contact@yasirshabbir.com](mailto:contact@yasirshabbir.com)

## License

This plugin is proprietary software developed by Yasir Shabbir.
