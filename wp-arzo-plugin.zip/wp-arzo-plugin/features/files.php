<?php
/**
 * File Manager Feature
 *
 * Provides file management capabilities:
 * - Browse directories
 * - Upload files
 * - Download files
 * - Edit text files
 * - View file contents
 * - Delete files
 *
 * @package WP_Arzo
 * @since 1.0.0
 */

// Security check
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Check if a file is editable based on its extension
 */
function isEditableFile($file_path)
{
    $editable_extensions = ['php', 'html', 'htm', 'css', 'js', 'json', 'xml', 'txt', 'md', 'sql', 'htaccess', 'log', 'ini', 'conf', 'yml', 'yaml'];
    $extension = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
    return in_array($extension, $editable_extensions) || basename($file_path) === '.htaccess';
}

/**
 * Check if a file is an image based on its extension
 */
function isImageFile($file_path)
{
    $image_extensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg'];
    $extension = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
    return in_array($extension, $image_extensions);
}

/**
 * Check if a file is binary
 */
function isBinaryFile($file_path)
{
    if (!file_exists($file_path) || !is_file($file_path)) {
        return false;
    }

    $binary_extensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'pdf', 'zip', 'rar', 'tar', 'gz', 'exe', 'dll', 'so', 'dylib'];
    $extension = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));

    if (in_array($extension, $binary_extensions)) {
        return true;
    }

    // Check file content for binary data
    $handle = fopen($file_path, 'rb');
    $chunk = fread($handle, 1024);
    fclose($handle);

    return strpos($chunk, "\0") !== false;
}

/**
 * Get syntax highlighting class for a file
 */
function getSyntaxClass($file_path)
{
    $extension = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
    $syntax_map = [
        'php' => 'php',
        'html' => 'html',
        'htm' => 'html',
        'css' => 'css',
        'js' => 'javascript',
        'json' => 'json',
        'xml' => 'xml',
        'sql' => 'sql',
        'md' => 'markdown'
    ];
    return isset($syntax_map[$extension]) ? $syntax_map[$extension] : 'text';
}

/**
 * Get file icon emoji based on extension
 */
function getFileIcon($file_path)
{
    $extension = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
    $icon_map = [
        'pdf' => '📄',
        'doc' => '📝',
        'docx' => '📝',
        'xls' => '📊',
        'xlsx' => '📊',
        'ppt' => '📽️',
        'pptx' => '📽️',
        'zip' => '🗜️',
        'rar' => '🗜️',
        'tar' => '🗜️',
        'gz' => '🗜️',
        'mp3' => '🎵',
        'wav' => '🎵',
        'flac' => '🎵',
        'mp4' => '🎬',
        'avi' => '🎬',
        'mov' => '🎬',
        'mkv' => '🎬',
        'jpg' => '🖼️',
        'jpeg' => '🖼️',
        'png' => '🖼️',
        'gif' => '🖼️',
        'bmp' => '🖼️',
        'webp' => '🖼️',
        'exe' => '⚙️',
        'msi' => '⚙️',
        'sql' => '🗃️',
        'php' => '🐘',
        'js' => '📜',
        'css' => '🎨',
        'html' => '🌐'
    ];
    return isset($icon_map[$extension]) ? $icon_map[$extension] : '📄';
}

function handleFiles()
{
    $current_dir = isset($_GET['dir']) ? $_GET['dir'] : ABSPATH;
    $current_dir = realpath($current_dir);

    // Handle file editing
    if (isset($_POST['save_file'])) {
        $file_path = $_POST['file_path'];
        $file_content = $_POST['file_content'];

        if (file_put_contents($file_path, $file_content) !== false) {
            echo '<div class="success">File saved successfully!</div>';
        } else {
            echo '<div class="error">Error saving file!</div>';
        }
    }

    // Download logic moved to top of file before HTML output

    if (isset($_POST['upload_file'])) {
        $target_dir = $current_dir . '/';
        $target_file = $target_dir . basename($_FILES["file"]["name"]);

        if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
            echo '<div class="success">File uploaded successfully!</div>';
        } else {
            echo '<div class="error">Error uploading file!</div>';
        }
    }

    if (isset($_POST['delete_file'])) {
        $file_to_delete = $_POST['file_path'];
        if (unlink($file_to_delete)) {
            echo '<div class="success">File deleted successfully!</div>';
        } else {
            echo '<div class="error">Error deleting file!</div>';
        }
    }

    // Check if viewing/editing a specific file
    $view_file = isset($_GET['view']) ? $_GET['view'] : null;
    $edit_file = isset($_GET['edit']) ? $_GET['edit'] : null;

    // Helper functions moved to top of file before AJAX handling

?>
<div class="content">
    <h2>File Manager</h2>
    <p><strong>Current Directory:</strong> <?php echo $current_dir; ?></p>

    <h3>Upload File</h3>
    <form method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label>Select File:</label>
            <input type="file" name="file">
        </div>
        <button type="submit" name="upload_file" class="btn">Upload</button>
    </form>

    <h3>Directory Contents</h3>
    <div class="file-list">
        <table>
            <tr>
                <th>Name</th>
                <th>Type</th>
                <th>Size</th>
                <th>Modified</th>
                <th>Actions</th>
            </tr>
            <?php
                if ($current_dir !== ABSPATH) {
                    $parent_dir = dirname($current_dir);
                    echo '<tr><td><a href="' . admin_url('admin-ajax.php?action=wp_arzo_standalone&tab=files&dir=' . urlencode($parent_dir)) . '">../</a></td><td>Directory</td><td>-</td><td>-</td><td>-</td></tr>';
                }

                $files = scandir($current_dir);
                foreach ($files as $file) {
                    if ($file === '.' || $file === '..') continue;

                    $file_path = rtrim($current_dir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $file;
                    $is_dir = is_dir($file_path);
                    $size = $is_dir ? '-' : filesize($file_path);
                    $modified = date('Y-m-d H:i:s', filemtime($file_path));

                    echo '<tr>';
                    if ($is_dir) {
                        echo '<td><a href="' . admin_url('admin-ajax.php?action=wp_arzo_standalone&tab=files&dir=' . urlencode($file_path)) . '">' . $file . '/</a></td>';
                        echo '<td>Directory</td>';
                    } else {
                        echo '<td>' . $file . '</td>';
                        echo '<td>File</td>';
                    }
                    echo '<td>' . ($size === '-' ? '-' : number_format($size) . ' bytes') . '</td>';
                    echo '<td>' . $modified . '</td>';
                    echo '<td class="file-actions">';
                    if ($is_dir) {
                        echo '<a href="' . admin_url('admin-ajax.php?action=wp_arzo_standalone&tab=files&dir=' . urlencode($file_path)) . '" class="btn btn-primary" title="Open Directory"><i class="fas fa-folder-open"></i></a>';
                    } else {
                        // View button for all files
                        echo '<button onclick="viewFile(\'' . addslashes($file_path) . '\')" class="btn btn-info" title="View File"><i class="fas fa-eye"></i></button> ';

                        // Edit button for editable files
                        if (isEditableFile($file_path)) {
                            echo '<button onclick="editFile(\'' . addslashes($file_path) . '\')" class="btn btn-warning" title="Edit File"><i class="fas fa-edit"></i></button> ';
                        }

                        // Download button
                        echo '<a href="' . admin_url('admin-ajax.php?action=wp_arzo_standalone&tab=files&download=' . urlencode($file_path)) . '" class="btn btn-success" title="Download File"><i class="fas fa-download"></i></a> ';

                        // Delete button
                        echo '<form method="post" style="display:inline;">';
                        echo '<input type="hidden" name="file_path" value="' . $file_path . '">';
                        echo '<button type="submit" name="delete_file" class="btn btn-danger" onclick="return confirm(\'Are you sure?\');" title="Delete File"><i class="fas fa-trash"></i></button>';
                        echo '</form>';
                    }
                    echo '</td>';
                    echo '</tr>';
                }
                ?>
        </table>
    </div>

    <!-- Lightbox Modal -->
    <div id="fileLightbox" class="lightbox">
        <div class="lightbox-content">
            <div class="lightbox-header">
                <h3 id="lightboxTitle">File Viewer</h3>
                <button class="lightbox-close" onclick="closeLightbox()">&times;</button>
            </div>
            <div class="lightbox-body" id="lightboxBody">
                <!-- Content will be loaded here -->
            </div>
            <div class="lightbox-actions" id="lightboxActions">
                <!-- Actions will be loaded here -->
            </div>
        </div>
    </div>

</div>
<?php
}
