# WP Arzo Plugin - Installation Guide

## Quick Installation

### Method 1: Upload via WordPress Admin (Recommended)

1. **Zip the plugin folder**
   - Navigate to your project directory
   - Zip the entire `wp-arzo-plugin` folder
   - Name it `wp-arzo-plugin.zip`

2. **Upload to WordPress**
   - Log in to your WordPress admin panel
   - Go to `Plugins` → `Add New`
   - Click `Upload Plugin` button at the top
   - Click `Choose File` and select `wp-arzo-plugin.zip`
   - Click `Install Now`
   - Click `Activate Plugin`

3. **Access the Tool**
   - Look for the "WP Arzo" menu item in your admin sidebar (with tools icon)
   - Click on "WP Arzo" to open the tool in a new tab
   - The tool will open in a clean interface without WordPress admin elements

### Method 2: FTP/Manual Upload

1. **Upload the folder**
   - Connect to your website via FTP or File Manager
   - Navigate to `/wp-content/plugins/`
   - Upload the entire `wp-arzo-plugin` folder
   - The final path should be: `/wp-content/plugins/wp-arzo-plugin/`

2. **Activate the plugin**
   - Log in to WordPress admin
   - Go to `Plugins` → `Installed Plugins`
   - Find "WP Arzo - Maintenance & Administration Suite"
   - Click `Activate`

3. **Access the Tool**
   - Click on "WP Arzo" in the admin menu
   - The tool opens in a new tab

## Plugin Structure

```
wp-arzo-plugin/
├── wp-arzo.php                 (Main plugin file with WordPress headers)
├── wp-arzo-original.php        (Original standalone version - for reference)
├── index.php                   (Security - prevents directory browsing)
├── README.md                   (Plugin documentation)
├── INSTALLATION.md             (This file)
└── includes/
    ├── wp-arzo-standalone.php  (Main tool interface - modified version)
    └── index.php               (Security - prevents directory browsing)
```

## How It Works

1. **Menu Integration**: When you activate the plugin, it adds a "WP Arzo" menu item to your WordPress admin panel
2. **New Tab Behavior**: Clicking the menu item opens the tool in a new browser tab
3. **Clean Interface**: The tool displays in a standalone interface without WordPress dashboard elements
4. **Security**: Only administrators (users with `manage_options` capability) can access the tool
5. **No ACCESS_KEY**: Unlike the standalone version, this plugin uses WordPress's built-in authentication

## Differences from Standalone Version

| Feature | Standalone Version | Plugin Version |
|---------|-------------------|----------------|
| Installation | Upload single PHP file | Install as WordPress plugin |
| Access | Via URL with ACCESS_KEY | Via WordPress admin menu |
| Authentication | Custom ACCESS_KEY | WordPress admin capabilities |
| Interface | Opens directly | Opens in new tab from admin menu |
| Security | Manual key management | WordPress native authentication |
| Updates | Manual file replacement | Standard WordPress plugin updates |

## Requirements

- WordPress 5.0 or higher
- PHP 7.2 or higher
- Administrator account access
- Modern web browser (Chrome, Firefox, Safari, Edge)

## Troubleshooting

### Plugin doesn't appear in menu
- Make sure the plugin is activated
- Ensure you're logged in as an administrator
- Clear your browser cache and refresh

### Tool opens but shows blank page
- Check PHP error logs
- Ensure your PHP version is 7.2 or higher
- Verify file permissions (wp-arzo-plugin folder should be readable)

### Permission errors
- Only administrators can access this tool
- Check your user role in WordPress
- Contact your site administrator

## Support

For support and questions:
- **Email**: contact@yasirshabbir.com
- **Website**: https://yasirshabbir.com
- **GitHub**: https://github.com/yasirshabbirservices/maintenance-tool

## Security Notes

- This plugin provides powerful administrative tools
- Only install on sites where you trust all administrators
- Keep WordPress and PHP updated for security
- The plugin follows WordPress security best practices
- All actions are logged by WordPress audit capabilities

## Uninstallation

To remove the plugin:
1. Go to `Plugins` → `Installed Plugins`
2. Deactivate "WP Arzo"
3. Click `Delete` to remove all plugin files

Note: The plugin doesn't store any data in the database, so uninstallation is clean.
