<?php
/**
 * WP Arzo: Main Loader File
 *
 * This file loads all necessary components and handles routing
 *
 * @package WP_Arzo
 * @version 5.1
 */

// Security check
if (!defined('ABSPATH')) {
    exit;
}

// Load dependencies
require_once(plugin_dir_path(__FILE__) . 'helpers.php');
require_once(plugin_dir_path(__FILE__) . 'ajax-handlers.php');

// Load WordPress admin functions if needed
if (!function_exists('wp_delete_user')) {
    require_once(ABSPATH . 'wp-admin/includes/user.php');
}

// Handle login actions before any output
$login_message = '';
$login_redirect = '';

if (isset($_POST['login_as_user'])) {
    $user_id = intval($_POST['user_id']);
    $user = get_user_by('id', $user_id);

    if ($user) {
        ob_clean();
        wp_clear_auth_cookie();
        wp_set_current_user($user_id, $user->user_login);
        wp_set_auth_cookie($user_id, true);
        do_action('wp_login', $user->user_login, $user);
        $login_redirect = admin_url();
        $login_message = 'success|Login successful! Opening WordPress admin in new tab...';
    } else {
        $login_message = 'error|User not found!';
    }
}

if (isset($_POST['create_temp_admin'])) {
    $temp_username = 'temp_admin_' . time();
    $temp_password = wp_generate_password(16, true, true);
    $temp_email = 'temp@' . parse_url(home_url(), PHP_URL_HOST);

    $user_id = wp_create_user($temp_username, $temp_password, $temp_email);

    if (!is_wp_error($user_id)) {
        $user = new WP_User($user_id);
        $user->set_role('administrator');
        ob_clean();
        wp_clear_auth_cookie();
        wp_set_current_user($user_id, $temp_username);
        wp_set_auth_cookie($user_id, true);
        do_action('wp_login', $temp_username, $user);
        $login_redirect = admin_url();
        $login_message = 'success|<strong>Temporary Admin Created!</strong><br>Username: ' . $temp_username . '<br>Password: ' . $temp_password . '<br><em>Login successful! Opening WordPress admin in new tab...</em>';
    } else {
        $login_message = 'error|Error creating temporary admin: ' . $user_id->get_error_message();
    }
}

// Handle direct admin access
if (isset($_GET['maintenance_access'])) {
    $nonce = $_GET['maintenance_access'];
    if (get_transient('maintenance_access_' . $nonce)) {
        delete_transient('maintenance_access_' . $nonce);
        $admin_users = get_users(['role' => 'administrator', 'number' => 1]);
        if (!empty($admin_users)) {
            $admin_user = $admin_users[0];
            ob_clean();
            wp_clear_auth_cookie();
            wp_set_current_user($admin_user->ID, $admin_user->user_login);
            wp_set_auth_cookie($admin_user->ID, true);
            do_action('wp_login', $admin_user->user_login, $admin_user);
            wp_redirect(admin_url());
            exit;
        }
    }
}

// Handle file download
if (isset($_GET['download'])) {
    $file_path = $_GET['download'];
    if (DIRECTORY_SEPARATOR === '\\') {
        $file_path = str_replace('/', '\\', $file_path);
    }
    $file_path = realpath($file_path);

    if ($file_path && file_exists($file_path) && is_file($file_path)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($file_path) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file_path));
        readfile($file_path);
        exit;
    } else {
        die('File not found or access denied');
    }
}

// Get current action/tab
$action = $_GET['tab'] ?? $_GET['action'] ?? 'info';
if ($action === 'wp_arzo_standalone') {
    $action = 'info';
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>WordPress Maintenance Tool</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- External CSS -->
    <link rel="stylesheet" href="<?php echo WP_ARZO_PLUGIN_URL . 'assets/css/wp-arzo.css?v=' . WP_ARZO_VERSION; ?>">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Developer Info -->
    <div class="developer-info">
        <div class="dev-logo">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="50" height="50">
                <defs>
                    <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" style="stop-color:#16e791;stop-opacity:1" />
                        <stop offset="100%" style="stop-color:#0ea66b;stop-opacity:1" />
                    </linearGradient>
                </defs>
                <path fill="url(#grad1)"
                    d="M60,40 L100,20 L140,40 L140,100 L120,120 L100,100 L80,120 L60,100 Z M100,60 L120,80 L100,100 L80,80 Z" />
                <path fill="none" stroke="#fff" stroke-width="4"
                    d="M100,20 L100,180 M40,60 L160,140 M160,60 L40,140" />
            </svg>
        </div>
        <div class="dev-details">
            <strong>Yasir Shabbir</strong><br>
            <a href="mailto:contact@yasirshabbir.com">contact@yasirshabbir.com</a>
        </div>
        <div class="dev-links">
            <span style="font-size: 11px; color: #888;">v<?php echo WP_ARZO_VERSION; ?></span>
            <a href="https://github.com/yasirshabbirservices/maintenance-tool" target="_blank"
                style="color: #16e791; text-decoration: none; margin-left: 15px;">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                    viewBox="0 0 24 24" style="vertical-align: middle; margin-right: 5px;">
                    <path
                        d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z" />
                </svg>
                GitHub
            </a>
        </div>
    </div>

    <h1>WordPress Maintenance Tool</h1>

    <!-- Navigation -->
    <div class="nav">
        <a href="<?php echo admin_url('admin-ajax.php?action=wp_arzo_standalone&tab=info'); ?>"
            <?php echo ($action === 'info') ? 'class="active"' : ''; ?>>Site Info</a>
        <a href="<?php echo admin_url('admin-ajax.php?action=wp_arzo_standalone&tab=users'); ?>"
            <?php echo ($action === 'users') ? 'class="active"' : ''; ?>>Users</a>
        <a href="<?php echo admin_url('admin-ajax.php?action=wp_arzo_standalone&tab=database'); ?>"
            <?php echo ($action === 'database') ? 'class="active"' : ''; ?>>Database</a>
        <a href="<?php echo admin_url('admin-ajax.php?action=wp_arzo_standalone&tab=files'); ?>"
            <?php echo ($action === 'files') ? 'class="active"' : ''; ?>>Files</a>
        <a href="<?php echo admin_url('admin-ajax.php?action=wp_arzo_standalone&tab=plugins'); ?>"
            <?php echo ($action === 'plugins') ? 'class="active"' : ''; ?>>Plugins</a>
        <a href="<?php echo admin_url('admin-ajax.php?action=wp_arzo_standalone&tab=themes'); ?>"
            <?php echo ($action === 'themes') ? 'class="active"' : ''; ?>>Themes</a>
        <a href="<?php echo admin_url('admin-ajax.php?action=wp_arzo_standalone&tab=debug'); ?>"
            <?php echo ($action === 'debug') ? 'class="active"' : ''; ?>>Debug</a>
        <a href="<?php echo admin_url('admin-ajax.php?action=wp_arzo_standalone&tab=maintenance'); ?>"
            <?php echo ($action === 'maintenance') ? 'class="active"' : ''; ?>>Maintenance Modes</a>
        <a href="<?php echo admin_url('admin-ajax.php?action=wp_arzo_standalone&tab=extra_options'); ?>"
            <?php echo ($action === 'extra_options') ? 'class="active"' : ''; ?>>Extra Options</a>
        <a href="<?php echo admin_url('admin-ajax.php?action=wp_arzo_standalone&tab=login'); ?>"
            <?php echo ($action === 'login') ? 'class="active"' : ''; ?>>Quick Login</a>
    </div>

    <?php
    // Display login messages
    if ($login_message) {
        $message_parts = explode('|', $login_message);
        $message_type = $message_parts[0];
        $message_text = $message_parts[1];
        echo '<div class="' . $message_type . '">' . $message_text . '</div>';
    }

    // Add redirect script if needed
    if ($login_redirect) {
        echo '<script>setTimeout(function() { window.open("' . $login_redirect . '", "_blank"); }, 1000);</script>';
    }

    // Route to appropriate feature
    $feature_file = '';
    switch ($action) {
        case 'info':
            $feature_file = 'site-info.php';
            break;
        case 'users':
            $feature_file = 'users.php';
            break;
        case 'database':
            $feature_file = 'database.php';
            break;
        case 'files':
            $feature_file = 'files.php';
            break;
        case 'plugins':
            $feature_file = 'plugins.php';
            break;
        case 'themes':
            $feature_file = 'themes.php';
            break;
        case 'debug':
            $feature_file = 'debug.php';
            break;
        case 'maintenance':
            $feature_file = 'maintenance.php';
            break;
        case 'extra_options':
            $feature_file = 'extra-options.php';
            break;
        case 'login':
            $feature_file = 'quick-login.php';
            break;
        default:
            $feature_file = 'site-info.php';
    }

    // Include the feature file
    $feature_path = plugin_dir_path(__FILE__) . '../features/' . $feature_file;
    if (file_exists($feature_path)) {
        include($feature_path);
    } else {
        echo '<div class="error">Feature not found: ' . htmlspecialchars($feature_file) . '</div>';
    }
    ?>

    <!-- Lightbox for file viewing/editing -->
    <div id="lightbox" class="lightbox">
        <div class="lightbox-content">
            <div class="lightbox-header">
                <h2 id="lightboxTitle">File Viewer</h2>
                <span class="close-lightbox" onclick="closeLightbox()">&times;</span>
            </div>
            <div class="lightbox-body" id="lightboxBody">
                <!-- Content will be loaded here -->
            </div>
            <div class="lightbox-actions" id="lightboxActions">
                <!-- Action buttons will be loaded here -->
            </div>
        </div>
    </div>

    <!-- External JavaScript -->
    <script>
        // Localized data from WordPress
        var wpArzoData = {
            ajaxUrl: '<?php echo admin_url('admin-ajax.php'); ?>',
            adminUrl: '<?php echo admin_url(); ?>',
            pluginUrl: '<?php echo WP_ARZO_PLUGIN_URL; ?>',
            version: '<?php echo WP_ARZO_VERSION; ?>'
        };
    </script>
    <script src="<?php echo WP_ARZO_PLUGIN_URL . 'assets/js/wp-arzo.js?v=' . WP_ARZO_VERSION; ?>"></script>
</body>
</html>
