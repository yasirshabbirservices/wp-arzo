<?php

/**
 * WP Arzo AJAX Handlers
 *
 * Handles all AJAX operations for the WP Arzo plugin
 *
 * @package WP_Arzo
 * @version 5.1
 */

// Security check
if (!defined('ABSPATH')) {
    exit;
}

// Handle AJAX operations (check for 'tab' parameter since 'action' is used by WordPress)
if (isset($_GET['tab']) && $_GET['tab'] === 'ajax' && isset($_GET['operation'])) {
    header('Content-Type: application/json');

    $operation = $_GET['operation'];
    $response = ['success' => false, 'message' => 'Unknown operation'];

    switch ($operation) {
        /**
         * AJAX Operation: Get Users Page
         *
         * Retrieves paginated list of WordPress users
         * Parameters: page, per_page
         */
        case 'get_users_page':
            if (isset($_GET['page']) && isset($_GET['per_page'])) {
                $page = intval($_GET['page']);
                $per_page = intval($_GET['per_page']);

                $users = get_users(['number' => $per_page, 'offset' => ($page - 1) * $per_page]);
                $total_users = count_users();
                $total_users = $total_users['total_users'];

                $users_data = [];
                $current_user_id = get_current_user_id();

                foreach ($users as $user) {
                    $is_current = ($user->ID == $current_user_id);
                    $users_data[] = [
                        'id' => $user->ID,
                        'username' => $user->user_login,
                        'email' => $user->user_email,
                        'roles' => implode(', ', $user->roles),
                        'is_current' => $is_current
                    ];
                }

                $response = [
                    'success' => true,
                    'users' => $users_data,
                    'total' => $total_users,
                    'total_pages' => ceil($total_users / $per_page),
                    'current_page' => $page
                ];
            } else {
                $response = ['success' => false, 'message' => 'Missing page parameters'];
            }
            break;

        /**
         * AJAX Operation: Get Database Tables Page
         *
         * Retrieves paginated list of database tables
         * Parameters: page, per_page
         */
        case 'get_db_tables_page':
            if (isset($_GET['page']) && isset($_GET['per_page'])) {
                global $wpdb;
                $page = intval($_GET['page']);
                $per_page = intval($_GET['per_page']);

                $tables = $wpdb->get_results("SHOW TABLES", ARRAY_N);
                $total_tables = count($tables);

                $tables_data = [];
                $start = ($page - 1) * $per_page;
                $end = min($start + $per_page, $total_tables);

                for ($i = $start; $i < $end; $i++) {
                    if (isset($tables[$i])) {
                        $table_name = $tables[$i][0];
                        $count = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
                        $tables_data[] = [
                            'name' => $table_name,
                            'rows' => $count
                        ];
                    }
                }

                $response = [
                    'success' => true,
                    'tables' => $tables_data,
                    'total' => $total_tables,
                    'total_pages' => ceil($total_tables / $per_page),
                    'current_page' => $page
                ];
            } else {
                $response = ['success' => false, 'message' => 'Missing page parameters'];
            }
            break;

        /**
         * AJAX Operation: Get Plugins Page
         *
         * Retrieves paginated list of installed plugins
         * Parameters: page, per_page
         */
        case 'get_plugins_page':
            if (isset($_GET['page']) && isset($_GET['per_page'])) {
                $page = intval($_GET['page']);
                $per_page = intval($_GET['per_page']);

                $plugins = get_plugins();
                $total_plugins = count($plugins);

                $plugins_data = [];
                $start = ($page - 1) * $per_page;
                $end = min($start + $per_page, $total_plugins);

                $plugin_keys = array_keys($plugins);
                for ($i = $start; $i < $end; $i++) {
                    if (isset($plugin_keys[$i])) {
                        $plugin_file = $plugin_keys[$i];
                        $plugin_data = $plugins[$plugin_file];
                        $is_active = is_plugin_active($plugin_file);

                        $plugins_data[] = [
                            'file' => $plugin_file,
                            'name' => $plugin_data['Name'],
                            'version' => $plugin_data['Version'],
                            'is_active' => $is_active
                        ];
                    }
                }

                $response = [
                    'success' => true,
                    'plugins' => $plugins_data,
                    'total' => $total_plugins,
                    'total_pages' => ceil($total_plugins / $per_page),
                    'current_page' => $page
                ];
            } else {
                $response = ['success' => false, 'message' => 'Missing page parameters'];
            }
            break;

        /**
         * AJAX Operation: Clear Debug Log
         *
         * Clears the WordPress debug.log file
         */
        case 'clear_debug_log':
            $log_file = WP_CONTENT_DIR . '/debug.log';
            if (file_exists($log_file)) {
                // Clear the debug log file by writing an empty string to it
                if (file_put_contents($log_file, '') !== false) {
                    $response = ['success' => true, 'message' => 'Debug log cleared successfully'];
                } else {
                    $response = ['success' => false, 'message' => 'Failed to clear debug log'];
                }
            } else {
                $response = ['success' => false, 'message' => 'Debug log file does not exist'];
            }
            break;

        /**
         * AJAX Operation: View File
         *
         * Displays file content (text or binary preview)
         * Parameters: file (file path)
         */
        case 'view_file':
            if (isset($_GET['file'])) {
                $file_path = normalizePath($_GET['file']);

                // Debug logging removed to prevent JSON interference

                if (file_exists($file_path) && is_file($file_path)) {
                    $filename = basename($file_path);
                    $file_size = filesize($file_path);
                    $file_ext = strtoupper(pathinfo($file_path, PATHINFO_EXTENSION));
                    $modified = date('Y-m-d H:i:s', filemtime($file_path));

                    $file_info = "Size: " . number_format($file_size) . " bytes | Type: {$file_ext} | Modified: {$modified}";

                    if (isBinaryFile($file_path)) {
                        if (isImageFile($file_path)) {
                            // For images, show the image
                            $data_url = 'data:' . mime_content_type($file_path) . ';base64,' . base64_encode(file_get_contents($file_path));
                            $content = '<div class="binary-file-preview">';
                            $content .= '<img src="' . $data_url . '" alt="' . htmlspecialchars($filename) . '">';
                            $content .= '<p>' . $file_info . '</p>';
                            $content .= '</div>';
                        } else {
                            // For other binary files, show icon and info
                            $icon = getFileIcon($file_path);
                            $content = '<div class="binary-file-preview">';
                            $content .= '<div class="file-icon">' . $icon . '</div>';
                            $content .= '<h4>' . htmlspecialchars($filename) . '</h4>';
                            $content .= '<p>This is a binary file that cannot be displayed as text.</p>';
                            $content .= '<p>' . $file_info . '</p>';
                            $content .= '</div>';
                        }
                    } else {
                        // For text files, show content
                        $file_content = file_get_contents($file_path);
                        $syntax_class = getSyntaxClass($file_path);
                        $content = '<div style="margin-bottom: 10px; font-size: 12px; color: #999;">' . $file_info . '</div>';
                        $content .= '<pre style="background: #2A2A2A; color: #E0E0E0; padding: 15px; border-radius: 4px; overflow-x: auto; font-family: \'Courier New\', monospace; font-size: 13px; line-height: 1.5; margin: 0; white-space: pre-wrap; word-wrap: break-word; max-height: 60vh; overflow-y: auto;"><code>' . htmlspecialchars($file_content) . '</code></pre>';
                    }

                    $actions = '';
                    if (isEditableFile($file_path)) {
                        $actions .= '<button onclick="editFile(\'' . addslashes($file_path) . '\')" class="btn btn-warning" title="Edit File"><i class="fas fa-edit"></i> Edit</button> ';
                    }
                    $actions .= '<a href="' . admin_url('admin-ajax.php?action=wp_arzo_standalone&tab=files&download=' . urlencode($file_path)) . '" class="btn btn-success" title="Download File"><i class="fas fa-download"></i> Download</a> ';
                    $actions .= '<button onclick="closeLightbox()" class="btn btn-secondary" title="Close"><i class="fas fa-times"></i> Close</button>';

                    $response = [
                        'success' => true,
                        'filename' => $filename,
                        'content' => $content,
                        'actions' => $actions
                    ];
                } else {
                    $response = [
                        'success' => false,
                        'message' => 'File not found or not accessible',
                        'debug' => [
                            'original_path' => $_GET['file'],
                            'normalized_path' => $file_path,
                            'file_exists' => file_exists($file_path),
                            'is_file' => is_file($file_path),
                            'directory_separator' => DIRECTORY_SEPARATOR,
                            'realpath' => realpath($file_path)
                        ]
                    ];
                }
            }
            break;

        /**
         * AJAX Operation: Edit File
         *
         * Loads file content into an editable textarea
         * Parameters: file (file path)
         */
        case 'edit_file':
            if (isset($_GET['file'])) {
                $file_path = normalizePath($_GET['file']);

                // Debug logging removed to prevent JSON interference

                if (file_exists($file_path) && is_file($file_path) && isEditableFile($file_path)) {
                    $filename = basename($file_path);
                    $file_content = file_get_contents($file_path);
                    $syntax_class = getSyntaxClass($file_path);

                    $file_size = filesize($file_path);
                    $file_ext = strtoupper(pathinfo($file_path, PATHINFO_EXTENSION));
                    $modified = date('Y-m-d H:i:s', filemtime($file_path));
                    $file_info = "Size: " . number_format($file_size) . " bytes | Type: {$file_ext} | Modified: {$modified}";

                    $content = '<div style="margin-bottom: 10px; font-size: 12px; color: #999;">' . $file_info . '</div>';
                    $content .= '<textarea id="fileContentEditor" style="width: 100%; min-height: 500px; background: #2A2A2A; color: #E0E0E0; border: 1px solid #444444; border-radius: 4px; padding: 15px; font-family: \'Courier New\', monospace; font-size: 13px; line-height: 1.5; resize: vertical; box-sizing: border-box;">' . htmlspecialchars($file_content) . '</textarea>';

                    $actions = '<button onclick="saveFile(\'' . addslashes($file_path) . '\')" class="btn btn-primary" title="Save Changes"><i class="fas fa-save"></i> Save</button> ';
                    $actions .= '<button onclick="viewFile(\'' . addslashes($file_path) . '\')" class="btn btn-secondary" title="Cancel"><i class="fas fa-undo"></i> Cancel</button>';

                    $response = [
                        'success' => true,
                        'filename' => $filename,
                        'content' => $content,
                        'actions' => $actions
                    ];
                } else {
                    $response['message'] = 'File not found, not accessible, or not editable';
                }
            }
            break;

        /**
         * AJAX Operation: Save File
         *
         * Saves edited file content to disk
         * Parameters: file_path, file_content (POST)
         */
        case 'save_file':
            if (isset($_POST['file_path']) && isset($_POST['file_content'])) {
                $file_path = normalizePath($_POST['file_path']);
                $file_content = $_POST['file_content'];

                if (file_exists($file_path) && is_file($file_path) && isEditableFile($file_path)) {
                    if (file_put_contents($file_path, $file_content) !== false) {
                        $response = ['success' => true, 'message' => 'File saved successfully'];
                    } else {
                        $response['message'] = 'Error writing to file';
                    }
                } else {
                    $response['message'] = 'File not found, not accessible, or not editable';
                }
            }
            break;

        /**
         * AJAX Operation: Log Debug Change
         *
         * Logs debug setting changes to debug.log file
         * Parameters: setting_name, new_value OR log_entry (POST)
         */
        case 'log_debug_change':
            if (isset($_POST['setting_name']) && isset($_POST['new_value'])) {
                $setting = sanitize_text_field($_POST['setting_name']);
                $value = sanitize_text_field($_POST['new_value']);

                // Create log entry
                $timestamp = date('Y-m-d H:i:s');
                $log_entry = "[{$timestamp}] Debug setting '{$setting}' changed to: " . ($value == '1' ? 'enabled' : 'disabled') . "\n";

                // Write to debug log file
                $log_file = WP_CONTENT_DIR . '/debug.log';
                if (file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX) !== false) {
                    $response = ['success' => true, 'message' => 'Debug change logged successfully'];
                } else {
                    $response = ['success' => false, 'message' => 'Failed to write to debug log'];
                }
            } else if (isset($_POST['log_entry'])) {
                // Alternative method using direct log entry
                $log_entry = sanitize_text_field($_POST['log_entry']) . "\n";

                // Write to debug log file
                $log_file = WP_CONTENT_DIR . '/debug.log';
                if (file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX) !== false) {
                    $response = ['success' => true, 'message' => 'Debug change logged successfully'];
                } else {
                    $response = ['success' => false, 'message' => 'Failed to write to debug log'];
                }
            } else {
                $response = ['success' => false, 'message' => 'Missing required parameters'];
            }
            break;
    }

    echo json_encode($response);
    exit;
}
